﻿namespace Spanzuratoarea
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.newGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pas1 = new System.Windows.Forms.PictureBox();
            this.pas2 = new System.Windows.Forms.PictureBox();
            this.pas3 = new System.Windows.Forms.PictureBox();
            this.pas4 = new System.Windows.Forms.PictureBox();
            this.pas5 = new System.Windows.Forms.PictureBox();
            this.pas6 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pas1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pas2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pas3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pas4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pas5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pas6)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newGameToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(601, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // newGameToolStripMenuItem
            // 
            this.newGameToolStripMenuItem.Name = "newGameToolStripMenuItem";
            this.newGameToolStripMenuItem.Size = new System.Drawing.Size(77, 20);
            this.newGameToolStripMenuItem.Text = "New Game";
            this.newGameToolStripMenuItem.Click += new System.EventHandler(this.newGameToolStripMenuItem_Click);
            // 
            // pas1
            // 
            this.pas1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pas1.BackgroundImage")));
            this.pas1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pas1.InitialImage = null;
            this.pas1.Location = new System.Drawing.Point(0, 27);
            this.pas1.Name = "pas1";
            this.pas1.Size = new System.Drawing.Size(255, 252);
            this.pas1.TabIndex = 1;
            this.pas1.TabStop = false;
            this.pas1.Visible = false;
            // 
            // pas2
            // 
            this.pas2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pas2.BackgroundImage")));
            this.pas2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pas2.InitialImage = null;
            this.pas2.Location = new System.Drawing.Point(0, 27);
            this.pas2.Name = "pas2";
            this.pas2.Size = new System.Drawing.Size(255, 252);
            this.pas2.TabIndex = 2;
            this.pas2.TabStop = false;
            this.pas2.Visible = false;
            // 
            // pas3
            // 
            this.pas3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pas3.BackgroundImage")));
            this.pas3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pas3.InitialImage = null;
            this.pas3.Location = new System.Drawing.Point(0, 27);
            this.pas3.Name = "pas3";
            this.pas3.Size = new System.Drawing.Size(255, 252);
            this.pas3.TabIndex = 3;
            this.pas3.TabStop = false;
            this.pas3.Visible = false;
            // 
            // pas4
            // 
            this.pas4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pas4.BackgroundImage")));
            this.pas4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pas4.InitialImage = null;
            this.pas4.Location = new System.Drawing.Point(0, 27);
            this.pas4.Name = "pas4";
            this.pas4.Size = new System.Drawing.Size(255, 252);
            this.pas4.TabIndex = 4;
            this.pas4.TabStop = false;
            this.pas4.Visible = false;
            // 
            // pas5
            // 
            this.pas5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pas5.BackgroundImage")));
            this.pas5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pas5.InitialImage = null;
            this.pas5.Location = new System.Drawing.Point(0, 27);
            this.pas5.Name = "pas5";
            this.pas5.Size = new System.Drawing.Size(255, 252);
            this.pas5.TabIndex = 5;
            this.pas5.TabStop = false;
            this.pas5.Visible = false;
            // 
            // pas6
            // 
            this.pas6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pas6.BackgroundImage")));
            this.pas6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pas6.InitialImage = null;
            this.pas6.Location = new System.Drawing.Point(0, 27);
            this.pas6.Name = "pas6";
            this.pas6.Size = new System.Drawing.Size(255, 252);
            this.pas6.TabIndex = 6;
            this.pas6.TabStop = false;
            this.pas6.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(601, 342);
            this.Controls.Add(this.pas6);
            this.Controls.Add(this.pas5);
            this.Controls.Add(this.pas4);
            this.Controls.Add(this.pas3);
            this.Controls.Add(this.pas2);
            this.Controls.Add(this.pas1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Spanzuratoarea";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pas1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pas2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pas3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pas4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pas5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pas6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem newGameToolStripMenuItem;
        private System.Windows.Forms.PictureBox pas1;
        private System.Windows.Forms.PictureBox pas2;
        private System.Windows.Forms.PictureBox pas3;
        private System.Windows.Forms.PictureBox pas4;
        private System.Windows.Forms.PictureBox pas5;
        private System.Windows.Forms.PictureBox pas6;
    }
}

