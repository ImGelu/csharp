﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int[] numbers = { 109, 132, 155, 178 };

        List<string> qa = new List <string>();
        int nrLinii = 0, kIntrebari = 0, puncte = 0;


        public void newQuestion()
        {
            if (radioButton1.Checked == true)
            {
                MessageBox.Show("Raspuns corect !");
                puncte++;
            }

            label3.Text = Convert.ToString(puncte);

            int raspunsCorect = kIntrebari + 1;
            label2.Text = Convert.ToString(qa[kIntrebari]);

/*            radioButton1.Left = 10;
            radioButton2.Left = 20;
            radioButton3.Left = 30;
            radioButton4.Left = 40;
*/
            radioButton1.Text = Convert.ToString(qa[kIntrebari + 1]);
            radioButton2.Text = Convert.ToString(qa[kIntrebari + 2]);
            radioButton3.Text = Convert.ToString(qa[kIntrebari + 3]);
            radioButton4.Text = Convert.ToString(qa[kIntrebari + 4]);

            kIntrebari+=5;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string dir = Application.StartupPath;
            string fisier = dir + "//intrebari.txt";
            StreamReader sr = new StreamReader(fisier);
            while (!sr.EndOfStream) { qa.Add(sr.ReadLine()); nrLinii++; }
            sr.Close();
            newQuestion();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (kIntrebari >= nrLinii) MessageBox.Show("Nu mai sunt intrebari!");
            else newQuestion();

            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
        }

    }
}
