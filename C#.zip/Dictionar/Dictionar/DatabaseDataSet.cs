﻿namespace Dictionar {
    
    
    public partial class DatabaseDataSet {
    }
}
